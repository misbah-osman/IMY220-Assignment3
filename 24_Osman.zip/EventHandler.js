function EventHandler()
{
	constructor = function(events)
	{
		this.events = events;

	}


	this.getEventsBetweenDates = function(start, end)
	{
		return events.filter((event) => 
		{
			return event.dateStart >= start;
		}).filter((mm) => 
		{
			return mm.dateEnd <= end; 
		}) ;

	}

	this.getByMonth = function(month)
	{
		
		let d;
	
		return events.filter((event) => 
		{
			d = new Date(event.dateStart);
			if(d.getMonth() == month-1){
				return event;
			}
		});

        /*let d;
		return list.map((event) =>
		{
			d=new Date(event.dateStart);
			if(d == month){
				return event.dateStart;
			}
		});*/

	}

	this.getUniqueDateAndSort = function()
	{
		/*let list;
		// if given array of objects is provided
		if(args && arguments[0].constructor === Array) 
			list = arguments[0];
		// if list of objects is provided, use that, otherwise use member variable
		else list = args ? Array.prototype.slice.apply(arguments) : this.events;

		return list.map((event) =>
		{
			return "From "+ event.dateStart + " to " + event.dateEnd + ": " + event.name + "( " + event.description + ")";
		});*/

		return events.sort(function(a,b){
			return new Date(a.dateStart) - new Date(b.dateStart);
		  });

	}


	this.getSummary = function(args)
	{

		let list;
		if(args && arguments[0].constructor === Array) 
			list = arguments[0];
		else list = args ? Array.prototype.slice.apply(arguments) : this.events;

		return list.map((event) =>
		{
			if(event.dateStart == event.dateEnd){
				return "On "+ event.dateStart + ": " + event.name + "( " + event.description + ")";
			}else
			return "From "+ event.dateStart + " to " + event.dateEnd + ": " + event.name + "( " + event.description + ")";
		});

	}

}